# If you wan't to honor Jesus

- Please use this template, where we talk about reclaiming the rainbow.

- See the template here:
  https://dannyandcate.github.io/Rainbow/
