- # README

- We made this download available, so you have a working copy of a new website, in case you mess up any code.

- You can also put this download on your site, so others can download the template.

## If you wan't to honor Jesus

- Please use this template, where we talk about reclaiming the rainbow.

- See the template here:
  https://dannyandcate.github.io/Rainbow/
